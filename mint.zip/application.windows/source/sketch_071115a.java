import processing.core.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; public class sketch_071115a extends PApplet {class NFlock
{
    PApplet pApplet;
    
    class Bird
    {
        public double[] p, v, p0;
        public Bird(double[] p, double[] v) { this.p = p; this.v = v; }
    }
    
    int 
        count = 200,
        dimension = 6,
        world_width = 1280,
        world_height = 800,
        world_depth = 1280;

    double
        visibility = 60,
        cohesion = 1.0f,
        alignment = 1.20f,
        separation = 1.0f,
        attractor_strength = 0.000001f,
        momentum = 11.0f,
        randomness = .10f,
        mouse = 14,
        stall = 5;

    double[] 
        init_pmax = new double[] { world_width - (world_width * .2f), world_height - (world_height * .2f), world_depth - (world_depth * .2f), 200, 200, 200 },
        init_pmin = new double[] { world_width * .2f, world_height * .2f, world_depth * .2f , 55, 55, 55 },
        init_vmax = new double[] { 1, 1, 1, 0.0015f, 0.0025f, 0.0035f }, 
        init_vmin = new double[] { -1, -1, -1, -.001f, -.0090f, -.0070f },
        attractor = new double[] { world_width / 2, world_height / 2, world_depth - (world_depth *  .6f), 170, 248, 187 },
        random_min = new double[] { -2, -2, -2, 0, 0, 0},
        random_max = new double[] { 2, 2, 2, 1, 1, 1 };
        

    Bird[] birds;
    
    public NFlock initialize()
    {
        size(world_width, world_height);
        background(0xffffffff);
        
        // fix values
        visibility = Math.pow(visibility,2);
        stall = Math.pow(stall,2);
        
        birds = new Bird[count];

        for (int i = 0; i < birds.length; i++)
            birds[i] = new Bird(random(init_pmax, init_pmin),  random(init_vmax, init_vmin));
         
         return this;
    }
    public void iterate()
    {
      for (int j = 0; j < birds.length; j++)
      {
          solve_bird(birds[j]);
          draw_bird(birds[j]);
      }
      //trect(0,0,world_width,world_height,255,255,255,.5);
      //background(#ffffff);
    }
    
    public void solve_bird(Bird bird)
    {
        //println("solving");
        int num_birds_in_sight = 0;
        double[]
            cohesion_point = new double[dimension],
            alignment_vector = new double[dimension],
            separation_vector = new double[dimension];

        System.arraycopy(bird.p, 0, cohesion_point, 0, dimension);
        System.arraycopy(bird.v, 0, alignment_vector, 0, dimension);

        for (int i = 0; i < count; i++)
        {
            if (distance_squared(bird.p, birds[i].p) > visibility)
                continue;

            num_birds_in_sight++;

            // arithmetic mean
            for (int j = 0; j < dimension; j++)
                cohesion_point[j] = (num_birds_in_sight * cohesion_point[j] + birds[i].p[j]) / (num_birds_in_sight + 1);
                //cohesion_point[j] += birds[i].p[j];
            
            

            // simple sum, normalize later
            for (int j = 0; j < dimension; j++)
                alignment_vector[j] += birds[i].v[j];
                
            //println("alignment");
            //printArray(alignment_vector);

            // weighted sum (weight proportional to square of proximity)
            double d2 = distance_squared(bird.p, birds[i].p);
            for (int j = 0; j < dimension; j++)
                separation_vector[j] += d2 * (bird.p[j] - birds[i].p[j]);
        }
        
        
        attractor[0] = mouseX;
        attractor[1] = mouseY;
        
        //println("solved with " + num_birds_in_sight + " birds in sight");
        double[] to_attractor = difference(attractor, bird.p);
        double attractor_distance_squared = distance_squared(attractor, to_attractor);
        
        bird.v = sum(new double[][] {
            scale(cohesion, normalize(difference(cohesion_point, bird.p))),
            scale(alignment, normalize(alignment_vector)),
            scale(separation, normalize(separation_vector)),
            scale(attractor_strength * attractor_distance_squared, normalize(to_attractor)),
            scale(momentum, normalize(bird.v)),
            scale(randomness, random(random_min, random_max))
        });
        
        /*
        double[] v = new double[] { bird.v[0], bird.v[1] };
        double m2 = magnitude_squared(v);
        
        double r = m2 / stall;
        if(r < 1)
        {
            double[] rv = scale(1 / Math.sqrt(m2), v);
            bird.v[0] = rv[0];
            bird.v[1] = rv[1];
        }*/
        
        double m2 = magnitude_squared(bird.v);
        
        double r = m2 / stall;
        if(r < 1)
            bird.v = scale(1 / Math.sqrt(m2), bird.v);
    }

    public void draw_bird(Bird bird)
    {
        bird.p0 = bird.p;      
        bird.p = sum(new double[][] { bird.p, bird.v });
        tline((int)bird.p0[0], (int)bird.p0[1], (int)bird.p[0], (int)bird.p[1], (int)bird.p[3], (int)bird.p[4], (int)bird.p[5], (float)(bird.p[2] / world_depth) * .15f);
        //println("drawing bird: " + bird.p[0] + " " + bird.p[1]);
        
    }


    public double[] random(double[] upper, double[] lower)
    {
        double[] r = new double[upper.length];
        for (int i = 0; i < r.length; i++)
            r[i] = lower[i] + Math.random() * (upper[i] - lower[i]);
        return r;
    }

    public double distance_squared(double[] a, double[] b)
    {
        double r = 0, t = 0;
        for (int i = 0; i < a.length; i++)
        {
            t = (a[i] - b[i]);
            r += t * t;
        }
        return r;
    }

    public double magnitude_squared(double[] a)
    {
        return distance_squared(a, new double[a.length]);
    }

    public double[] sum(double[][] a)
    {
        double[] r = new double[a[0].length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[0].length; j++)
                r[j] += a[i][j];
        return r;
    }

    public double[] difference(double[] a, double[] b)
    {
        double[] r = new double[a.length];
        for (int i = 0; i < a.length; i++)
            r[i] = a[i] - b[i];
        return r;
    }

    public double[] scale(double a, double[] x)
    {
        double[] r = new double[x.length];
        for (int i = 0; i < x.length; i++)
            r[i] = a * x[i];
        return r;
    }

    public double[] normalize(double[] a)
    {
        //println("normalizing");
        //printArray(a);
        // slow. better way to find invsqrt?
        
        double m = magnitude_squared(a);
        
        if(Math.abs(m) < .0000000000001f)
          m = .0000000000001f;
        return scale(1 / Math.sqrt(m), a);
    }
    
    public double[] printArray(double[] a)
    {
        for(int i = 0; i < a.length; i++)
          print(a[i] + " ");
        println("");
        return a;
    }
    
    public void trect(int x, int y, int w, int h, int r, int g, int b, float a)
    {
        for(int i = 0; i < h; i++)
            tline(x, h + i, x + w, h + i, r, g, b, a);
    }
    
    public void tline(int x0, int y0, int x1, int y1, int r, int g, int b, float a)
    {
        // a nearly perfect implementation...
        // when one end is anchored to the center of the screen, and the other
        // attached to the mouse, for some reason it tends to partially neglect
        // the vertical and horizontal lines coming from the attachment point.
        // this is almost certainly a rounding issue.
        int dy = y1 - y0;
        int dx = x1 - x0;
  
        int signdy = dy == 0 ? 0 : (dy > 0 ? 1 : -1);
        int signdx = dx == 0 ? 0 : (dx > 0 ? 1 : -1);

        if(dy == 0 && dx == 0)
        {
            tpoint(x0,y0,r,g,b,a);
            return;
        }
        if (Math.abs(dy) >= Math.abs(dx))
        {
          for(int i = 0; i < Math.abs(dy); i++)
            tpoint(x0 + signdy * i * dx / dy, y0 + signdy * i, r, g, b, a);
          return;
        }
        if (Math.abs(dy) < Math.abs(dx))
        {
            for(int i = 0; i < Math.abs(dx); i++)
            tpoint(x0 + signdx * i, y0 + signdx * i * dy / dx, r, g, b, a);
          return;
        }
    }
    
    public void tpoint(int x, int y, int r, int g, int b, float a)
    {
        int c = get(x, y);
        float ur = red(c);
        float ug = green(c);
        float ub = blue(c);
        
        int r1 = (int)Math.min(ur, ur + (r - ur) * a);
        int g1 = (int)Math.min(ug, ug +(g - ug) * a);
        int b1 = (int)Math.min(ub, ub + (b - ub) * a);
        stroke(color(r1, g1, b1));
        point(x,y);
  }
}

NFlock flock;
int iterations = 0;
public void setup() { flock = new NFlock().initialize(); }
public void draw() { flock.iterate(); }

/*void setup()
{
  double[] i = new double[1];
  println("it is" + i[0]);
}*/

  static public void main(String args[]) {     PApplet.main(new String[] { "sketch_071115a" });  }}